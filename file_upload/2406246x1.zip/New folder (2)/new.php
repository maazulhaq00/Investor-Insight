<?php
include 'connection.php';

// Handle the update request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $original_valuation_points = $_POST['original_valuation_points'];
    $updates = [];
    $params = [];
    $types = '';

    if (!empty($_POST['valuation_points'])) {
        $updates[] = "valuation_points=?";
        $params[] = $_POST['valuation_points'];
        $types .= 's';
    }
    if (!empty($_POST['fund_nav'])) {
        $updates[] = "fund_nav=?";
        $params[] = $_POST['fund_nav'];
        $types .= 's';
    }
    if (!empty($_POST['tasi'])) {
        $updates[] = "tasi=?";
        $params[] = $_POST['tasi'];
        $types .= 's';
    }
    if (!empty($_POST['sp_500'])) {
        $updates[] = "sp_500=?";
        $params[] = $_POST['sp_500'];
        $types .= 's';
    }
    if (!empty($_POST['dividend_per_share'])) {
        $updates[] = "dividend_per_share=?";
        $params[] = $_POST['dividend_per_share'];
        $types .= 's';
    }
    if (!empty($_POST['realized_gain_or_loss'])) {
        $updates[] = "realized_gain_or_loss=?";
        $params[] = $_POST['realized_gain_or_loss'];
        $types .= 's';
    }
    if (!empty($_POST['total_fund_commitment'])) {
        $updates[] = "total_fund_commitment=?";
        $params[] = $_POST['total_fund_commitment'];
        $types .= 's';
    }
    if (!empty($_POST['investment_multiples'])) {
        $updates[] = "investment_multiples=?";
        $params[] = $_POST['investment_multiples'];
        $types .= 's';
    }
    if (!empty($_POST['investor_count'])) {
        $updates[] = "investor_count=?";
        $params[] = $_POST['investor_count'];
        $types .= 's';
    }
    if (!empty($_POST['investment_count'])) {
        $updates[] = "investment_count=?";
        $params[] = $_POST['investment_count'];
        $types .= 's';
    }

    $params[] = $id;
    $params[] = $original_valuation_points;
    $types .= 'ss';

    if (!empty($updates)) {
        $update_sql = "UPDATE client_data SET " . implode(', ', $updates) . " WHERE id=? AND valuation_points=?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param($types, ...$params);

        if ($stmt->execute()) {
            echo "Success";
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        echo "No changes detected.";
    }
    exit;
}

// Fetch distinct client_id values
$client_sql = "SELECT DISTINCT client_id FROM client_data";
$client_result = mysqli_query($conn, $client_sql);

// Initialize variables
$selected_client_id = isset($_GET['client_id']) ? $_GET['client_id'] : '';
$selected_graph_type = isset($_GET['graph_type']) ? $_GET['graph_type'] : '';
$selected_graph1 = isset($_GET['graph_type1']) ? $_GET['graph_type1'] : '';
$client_data = [];

if (!empty($selected_client_id) && !empty($selected_graph_type)) {
    $sql = "SELECT * FROM client_data WHERE client_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $selected_client_id);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $client_data[] = $row;
    }
}

$sql_graph = "SELECT * FROM graphname";
$graph_result = mysqli_query($conn, $sql_graph);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic Data Display</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <style>
    table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
        font-size: 16px;
        text-align: left;
    }

    table thead th {
        background-color: #333;
        color: white;
        padding: 10px;
        border: 1px solid #ddd;
    }

    table tbody td {
        padding: 10px;
        border: 1px solid #ddd;
    }

    table tbody tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    table tbody tr:hover {
        background-color: #f5f5f5;
    }

    button {
        background-color: #d9480f;
        color: white;
        border-radius: 5px;
        border: 1px solid #d9480f;
        padding: 5px 10px;
        cursor: pointer;
        font-size: 14px;
    }

    button:hover {
        background-color: #bf3e0a;
    }

    button:focus {
        outline: none;
    }

    a {
        text-decoration: none;
    }

    #data_table {
        display: none;
    }
    </style>
</head>

<body>
    <form>
        <select name="graph_type" id="selectOption" onchange="updateURL()">
            <option value="">Select graph</option>
            <option value="nav_fund" <?php echo $selected_graph_type == 'nav_fund' ? 'selected' : ''; ?>>Nav Fund
            </option>
            <option value="nav_performance" <?php echo $selected_graph_type == 'nav_performance' ? 'selected' : ''; ?>>
                Nav Performance</option>
            <option value="realized_gain" <?php echo $selected_graph_type == 'realized_gain' ? 'selected' : ''; ?>>
                Realized Gain</option>
            <option value="dividend_per_share"
                <?php echo $selected_graph_type == 'dividend_per_share' ? 'selected' : ''; ?>>Dividend Per Share
            </option>
            <option value="Sparklinegraph" <?php echo $selected_graph_type == 'Sparklinegraph' ? 'selected' : ''; ?>>
                Spark Line
            </option>
        </select>

        <select name="graph_type1" id="selectOption1" onchange="updateURL()">
            <option value="">Select graph type</option>
            <option value="nav1" <?php echo $selected_graph1 == 'nav1' ? 'selected' : ''; ?>>Nav Performance
                1
            </option>
            <option value="nav2" <?php echo $selected_graph1 == 'nav2' ? 'selected' : ''; ?>>Nav Performance
                2
            </option>

        </select>

        <select name="client_id" id="clientSelect" onchange="updateURL()">
            <option value="">Select Client ID</option>
            <?php while ($client_row = mysqli_fetch_assoc($client_result)) : ?>
            <option value="<?php echo htmlspecialchars($client_row['client_id']); ?>"
                <?php echo $selected_client_id == $client_row['client_id'] ? 'selected' : ''; ?>>
                <?php echo htmlspecialchars($client_row['client_id']); ?>
            </option>
            <?php endwhile; ?>
        </select>

    </form>

    <div id="no_data_message" style="display: none;">No data available</div>

    <div id="data_table">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Valuation Points</th>
                    <?php if ($selected_graph_type == 'nav_fund' || $selected_graph_type == 'nav_performance') : ?>
                    <th>Fund NAV</th>
                    <?php endif; ?>
                    <?php if ($selected_graph_type == 'nav_fund') : ?>
                    <th>TASI</th>
                    <th>S&P 500</th>
                    <?php endif; ?>
                    <?php if ($selected_graph_type == 'nav_performance' || $selected_graph_type == 'dividend_per_share') : ?>
                    <th>Dividend Per Share</th>
                    <?php endif; ?>
                    <?php if ($selected_graph_type == 'realized_gain') : ?>
                    <th>Realized Gain</th>
                    <?php endif; ?>
                    <?php if ($selected_graph_type == 'Sparklinegraph') : ?>
                    <th>total_fund_commitment</th>
                    <th>investment_multiples</th>
                    <th>investor_count</th>
                    <th>investment_count</th>
                    <?php endif; ?>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($client_data as $row) : ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                    <td contenteditable="true"><?php echo htmlspecialchars($row['valuation_points']); ?></td>
                    <?php if ($selected_graph_type == 'nav_fund' || $selected_graph_type == 'nav_performance') : ?>
                    <td contenteditable="true"><?php echo htmlspecialchars($row['fund_nav']); ?></td>
                    <?php endif; ?>
                    <?php if ($selected_graph_type == 'nav_fund') : ?>
                    <td contenteditable="true"><?php echo htmlspecialchars($row['tasi']); ?></td>
                    <td contenteditable="true"><?php echo htmlspecialchars($row['sp_500']); ?></td>
                    <?php endif; ?>
                    <?php if ($selected_graph_type == 'nav_performance' || $selected_graph_type == 'dividend_per_share') : ?>
                    <td contenteditable="true"><?php echo htmlspecialchars($row['dividend_per_share']); ?></td>
                    <?php endif; ?>
                    <?php if ($selected_graph_type == 'realized_gain') : ?>
                    <td contenteditable="true"><?php echo htmlspecialchars($row['realized_gain_or_loss']); ?></td>
                    <?php endif; ?>
                    <?php if ($selected_graph_type == 'Sparklinegraph') : ?>
                    <td contenteditable="true"><?php echo htmlspecialchars($row['total_fund_commitment']); ?></td>
                    <td contenteditable="true"><?php echo htmlspecialchars($row['investment_multiples']); ?></td>
                    <td contenteditable="true"><?php echo htmlspecialchars($row['investor_count']); ?></td>
                    <td contenteditable="true"><?php echo htmlspecialchars($row['investment_count']); ?></td>
                    <?php endif; ?>
                    <td>
                        <input type="hidden" name="original_valuation_points"
                            value="<?php echo htmlspecialchars($row['valuation_points']); ?>">
                        <button class="editBtn">Submit
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <!-- <div id="updateMessage"></div> -->
        <div class="alert alert-success" role="alert" id="updateMessage" style="display: none;"></div>

    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
    function updateURL() {
        var graphType = document.getElementById('selectOption').value;
        var graphType1 = document.getElementById('selectOption1').value;
        var clientId = document.getElementById('clientSelect').value;
        var params = new URLSearchParams(window.location.search);
        if (graphType) {
            params.set('graph_type', graphType);
        } else {
            params.delete('graph_type');
        }
        if (graphType1) {
            params.set('graph_type1', graphType1);
        } else {
            params.delete('graph_type1');
        }
        if (clientId) {
            params.set('client_id', clientId);
        } else {
            params.delete('client_id');
        }
        window.location.search = params.toString();
    }

    function editRow(button) {
        var row = button.closest('tr');
        var rowData = {
            id: row.cells[0].innerText,
            valuation_points: row.cells[1].innerText,
            original_valuation_points: row.querySelector('[name="original_valuation_points"]').value
        };

        var selectedGraphType = document.getElementById('selectOption').value;

        switch (selectedGraphType) {
            case 'nav_fund':
                rowData.fund_nav = row.cells[2].innerText;
                rowData.tasi = row.cells[3].innerText;
                rowData.sp_500 = row.cells[4].innerText;
                break;
            case 'nav_performance':
                rowData.fund_nav = row.cells[2].innerText;
                rowData.dividend_per_share = row.cells[3].innerText;
                break;
            case 'realized_gain':
                rowData.realized_gain_or_loss = row.cells[2].innerText;
                break;
            case 'dividend_per_share':
                rowData.dividend_per_share = row.cells[2].innerText;
                break;
            case 'Sparklinegraph':
                rowData.total_fund_commitment = row.cells[2].innerText;
                rowData.investment_multiples = row.cells[3].innerText;
                rowData.investor_count = row.cells[4].innerText;
                rowData.investment_count = row.cells[5].innerText;
                break;
            default:
                break;
        }

        updateRow(rowData);
    }

    function updateRow(rowData) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    if (xhr.responseText.trim() === 'Success') {
                        document.getElementById('updateMessage').innerText = 'Data updated successfully';
                    } else {
                        document.getElementById('updateMessage').innerText = 'Error updating row: ' + xhr
                            .responseText;
                    }
                } else {
                    document.getElementById('updateMessage').innerText = 'Error updating row';
                }
            }
        };
        var params = new URLSearchParams();
        for (var key in rowData) {
            if (rowData[key] !== null) {
                params.append(key, rowData[key]);
            }
        }
        xhr.send(params.toString());

        // Show the update message
        document.getElementById('updateMessage').style.display = 'block';
    }

    document.querySelectorAll('.editBtn').forEach(function(button) {
        button.addEventListener('click', function() {
            editRow(button);
        });
    });



    window.onload = function() {
        var clientSelect = document.getElementById('clientSelect');
        var graphType = document.getElementById('selectOption').value;
        var clientId = clientSelect.value;
        var dataTable = document.getElementById('data_table');
        var noDataMessage = document.getElementById('no_data_message');

        if (graphType && clientId) {
            if (<?php echo count($client_data); ?> > 0) {
                dataTable.style.display = 'block';
                noDataMessage.style.display = 'none';
            } else {
                dataTable.style.display = 'none';
                noDataMessage.style.display = 'block';
            }
        } else {
            dataTable.style.display = 'none';
            noDataMessage.style.display = 'none';
        }

        clientSelect.addEventListener('change', updateURL);
    };
    </script>

</body>

</html>