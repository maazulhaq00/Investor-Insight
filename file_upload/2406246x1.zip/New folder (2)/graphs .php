<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php

include 'connection.php';
include 'new.php';
    
$graph_nav_per_1 = "Nav performance 1";
$graph_nav_per_2 = "Nav performance 2";


if($selected_graph1 == $graph_nav_per_1){
    
}
?>


</body>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

</html>