<?php
include 'connection.php';

// Handle the update request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'update') {
        // Handle update
        $id = $_POST['id'] ?? null;
        $original_valuation_points = $_POST['original_valuation_points'] ?? null;
        $updates = [];
        $params = [];
        $types = '';

        $fields = [
            'valuation_points',
            'fund_nav',
            'tasi',
            'sp_500',
            'dividend_per_share',
            'realized_gain_or_loss',
            'total_fund_commitment',
            'investment_multiples',
            'investor_count',
            'investment_count'
        ];

        foreach ($fields as $field) {
            if (!empty($_POST[$field])) {
                $updates[] = "$field=?";
                $params[] = $_POST[$field];
                $types .= 's';
            }
        }

        if ($id && $original_valuation_points && !empty($updates)) {
            $params[] = $id;
            $params[] = $original_valuation_points;
            $types .= 'ss';

            $update_sql = "UPDATE client_data SET " . implode(', ', $updates) . " WHERE id=? AND valuation_points=?";
            $stmt = $conn->prepare($update_sql);
            $stmt->bind_param($types, ...$params);

            if ($stmt->execute()) {
                echo "Success";
            } else {
                echo "Error: " . $stmt->error;
            }
        } else {
            echo "No changes detected.";
        }
    } elseif ($_POST['action'] === 'insert') {
        // Handle insert
        $client_id = $_POST['client_id'] ?? 0;
        $graph_type = $_POST['graph_type'] ?? 0;
        $valuation_points = $_POST['valuation_points'] ?? 0;
        $fund_nav = $_POST['fund_nav'] ?? 0;
        $tasi = $_POST['tasi'] ?? 0;
        $sp_500 = $_POST['sp_500'] ?? 0;
        $realized_gain = $_POST['realized_gain'] ?? 0;
        $dividend_per_share = $_POST['dividend_per_share'] ?? 0;
        $total_fund_commitment = $_POST['total_fund_commitment'] ?? 0;
        $assets_under_management = $_POST['assets_under_management'] ?? 0;
        $holding_positions = $_POST['Holding_positions'] ?? 0;
        $no_of_investor = $_POST['no_of_investor'] ?? 0;

        $sql_insert = "INSERT INTO client_data (client_id, valuation_points, fund_nav, tasi, sp_500, realized_gain_or_loss, dividend_per_share, total_fund_commitment, investment_multiples, investor_count, investment_count, graph_type)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt_insert = $conn->prepare($sql_insert);
        $stmt_insert->bind_param('ssssssssssss', $client_id, $valuation_points, $fund_nav, $tasi, $sp_500, $realized_gain, $dividend_per_share, $total_fund_commitment, $assets_under_management, $no_of_investor, $holding_positions, $graph_type);

        if ($stmt_insert->execute()) {
            echo "Success";
        } else {
            echo "Error: " . $stmt_insert->error;
        }
    }
    exit;
}

// Fetch distinct client_id values
$client_sql = "SELECT DISTINCT client_id FROM client_data";
$client_result = mysqli_query($conn, $client_sql);

// Initialize variables
$selected_client_id = $_GET['client_id'] ?? '';
$selected_graph_type = $_GET['graph_type'] ?? '';
$selected_graph1 = $_GET['graph_type1'] ?? '';
$client_data = [];

if (!empty($selected_client_id) && !empty($selected_graph_type)) {
    $sql = "SELECT * FROM client_data WHERE client_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $selected_client_id);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $client_data[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic Data Display</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <style>
    /* CSS styles */
    </style>
</head>

<body>
    <form>
        <select name="graph_type" id="selectOption" onchange="updateURL()">
            <option value="">Select graph</option>
            <option value="nav_fund" <?php echo $selected_graph_type == 'nav_fund' ? 'selected' : ''; ?>>Nav Fund
            </option>
            <option value="nav_performance" <?php echo $selected_graph_type == 'nav_performance' ? 'selected' : ''; ?>>
                Nav Performance</option>
            <option value="realized_gain" <?php echo $selected_graph_type == 'realized_gain' ? 'selected' : ''; ?>>
                Realized Gain</option>
            <option value="dividend_per_share"
                <?php echo $selected_graph_type == 'dividend_per_share' ? 'selected' : ''; ?>>Dividend Per Share
            </option>
            <option value="Sparklinegraph" <?php echo $selected_graph_type == 'Sparklinegraph' ? 'selected' : ''; ?>>
                Spark Line
            </option>
        </select>

        <select name="graph_type1" id="selectOption1" onchange="updateURL()">
            <option value="">Select graph type</option>
            <option value="nav1" <?php echo $selected_graph1 == 'nav1' ? 'selected' : ''; ?>>Nav Performance
                1
            </option>
            <option value="nav2" <?php echo $selected_graph1 == 'nav2' ? 'selected' : ''; ?>>Nav Performance
                2
            </option>

        </select>

        <select name="client_id" id="clientSelect" onchange="updateURL()">
            <option value="">Select Client ID</option>
            <?php while ($client_row = mysqli_fetch_assoc($client_result)) : ?>
            <option value="<?php echo htmlspecialchars($client_row['client_id']); ?>"
                <?php echo $selected_client_id == $client_row['client_id'] ? 'selected' : ''; ?>>
                <?php echo htmlspecialchars($client_row['client_id']); ?>
            </option>
            <?php endwhile; ?>
        </select>

    </form>
    <!-- HTML content -->
    <form id="updateForm" method="post">
        <!-- Input fields for update -->
        <input type="hidden" name="action" value="update">
        <!-- Other input fields -->
    </form>

    <form id="insertForm" method="post">
        <!-- Input fields for insert -->
        <input type="hidden" name="action" value="insert">
        <!-- Other input fields -->
    </form>

    <script>
    function updateRow(button) {
        var row = button.closest('tr');
        var rowData = {
            id: row.cells[0].innerText,
            valuation_points: row.cells[1].innerText,
            original_valuation_points: row.querySelector('[name="original_valuation_points"]').value
        };

        // Set other fields based on your form structure
        // For example:
        // rowData.fund_nav = row.cells[2].innerText;
        // rowData.tasi = row.cells[3].innerText;
        // ...

        var form = document.getElementById('updateForm');
        for (var key in rowData) {
            if (rowData.hasOwnProperty(key)) {
                var input = document.createElement('input');
                input.type = 'hidden';
                input.name = key;
                input.value = rowData[key];
                form.appendChild(input);
            }
        }
        form.submit();
    }

    function newRow() {
        // Implement code to submit data for new row insertion
        var form = document.getElementById('insertForm');
        // Populate form fields with data from your inputs
        form.submit();
    }
    </script>
</body>

</html>