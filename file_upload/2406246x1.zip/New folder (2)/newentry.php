<?php
include "connection.php";

$client_sql = "SELECT DISTINCT client_id FROM client_data";
$client_result = mysqli_query($conn, $client_sql);

// Initialize variables
$selected_client_id = isset($_GET['client_id']) ? $_GET['client_id'] : '';
$selected_graph_type = isset($_GET['graph_type']) ? $_GET['graph_type'] : '';
$selected_graph1 = isset($_GET['graph_type1']) ? $_GET['graph_type1'] : '';
$client_data = [];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form>
        <select name="graph_type" id="selectOption" onchange="updateURL()">
            <option value="">Select graph</option>
            <option value="nav_fund" <?php echo $selected_graph_type == 'nav_fund' ? 'selected' : ''; ?>>Nav Fund
            </option>
            <option value="nav_performance" <?php echo $selected_graph_type == 'nav_performance' ? 'selected' : ''; ?>>
                Nav Performance</option>
            <option value="realized_gain" <?php echo $selected_graph_type == 'realized_gain' ? 'selected' : ''; ?>>
                Realized Gain</option>
            <option value="dividend_per_share"
                <?php echo $selected_graph_type == 'dividend_per_share' ? 'selected' : ''; ?>>Dividend Per Share
            </option>
            <option value="Sparklinegraph" <?php echo $selected_graph_type == 'Sparklinegraph' ? 'selected' : ''; ?>>
                Spark Line
            </option>
        </select>

        <select name="graph_type1" id="selectOption1" onchange="updateURL()">
            <option value="">Select graph type</option>
            <option value="nav1" <?php echo $selected_graph1 == 'nav1' ? 'selected' : ''; ?>>Nav Performance
                1
            </option>
            <option value="nav2" <?php echo $selected_graph1 == 'nav2' ? 'selected' : ''; ?>>Nav Performance
                2
            </option>

        </select>

        <select name="client_id" id="clientSelect" onchange="updateURL()">
            <option value="">Select Client ID</option>
            <?php while ($client_row = mysqli_fetch_assoc($client_result)) : ?>
            <option value="<?php echo htmlspecialchars($client_row['client_id']); ?>"
                <?php echo $selected_client_id == $client_row['client_id'] ? 'selected' : ''; ?>>
                <?php echo htmlspecialchars($client_row['client_id']); ?>
            </option>
            <?php endwhile; ?>
        </select>

    </form>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Valuation Points</th>
                <?php if ($selected_graph_type == 'nav_fund' || $selected_graph_type == 'nav_performance') : ?>
                <th>Fund NAV</th>
                <?php endif; ?>
                <?php if ($selected_graph_type == 'nav_fund') : ?>
                <th>TASI</th>
                <th>S&P 500</th>
                <?php endif; ?>
                <?php if ($selected_graph_type == 'nav_performance' || $selected_graph_type == 'dividend_per_share') : ?>
                <th>Dividend Per Share</th>
                <?php endif; ?>
                <?php if ($selected_graph_type == 'realized_gain') : ?>
                <th>Realized Gain</th>
                <?php endif; ?>
                <?php if ($selected_graph_type == 'Sparklinegraph') : ?>
                <th>total_fund_commitment</th>
                <th>investment_multiples</th>
                <th>investor_count</th>
                <th>investment_count</th>
                <?php endif; ?>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($client_data as $row) : ?>
            <tr>
                <td><?php echo htmlspecialchars($row['id']); ?></td>
                <td contenteditable="true"><?php echo htmlspecialchars($row['valuation_points']); ?></td>
                <?php if ($selected_graph_type == 'nav_fund' || $selected_graph_type == 'nav_performance') : ?>
                <td contenteditable="true"><?php echo htmlspecialchars($row['fund_nav']); ?></td>
                <?php endif; ?>
                <?php if ($selected_graph_type == 'nav_fund') : ?>
                <td contenteditable="true"><?php echo htmlspecialchars($row['tasi']); ?></td>
                <td contenteditable="true"><?php echo htmlspecialchars($row['sp_500']); ?></td>
                <?php endif; ?>
                <?php if ($selected_graph_type == 'nav_performance' || $selected_graph_type == 'dividend_per_share') : ?>
                <td contenteditable="true"><?php echo htmlspecialchars($row['dividend_per_share']); ?></td>
                <?php endif; ?>
                <?php if ($selected_graph_type == 'realized_gain') : ?>
                <td contenteditable="true"><?php echo htmlspecialchars($row['realized_gain_or_loss']); ?></td>
                <?php endif; ?>
                <?php if ($selected_graph_type == 'Sparklinegraph') : ?>
                <td contenteditable="true"><?php echo htmlspecialchars($row['total_fund_commitment']); ?></td>
                <td contenteditable="true"><?php echo htmlspecialchars($row['investment_multiples']); ?></td>
                <td contenteditable="true"><?php echo htmlspecialchars($row['investor_count']); ?></td>
                <td contenteditable="true"><?php echo htmlspecialchars($row['investment_count']); ?></td>
                <?php endif; ?>
                <td>
                    <input type="hidden" name="original_valuation_points"
                        value="<?php echo htmlspecialchars($row['valuation_points']); ?>">
                    <button class="editBtn">Submit
                    </button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <!-- <div id="updateMessage"></div> -->
    <div class="alert alert-success" role="alert" id="updateMessage" style="display: none;"></div>
</body>
<script>

</script>

</html>